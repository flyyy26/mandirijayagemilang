<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sesi Habis</title>
    <meta http-equiv="refresh" content="5;url={{ route('login') }}" />
</head>
<body>
    <div style="text-align: center; margin-top: 20%;">
        <h1>Sesi sudah habis</h1>
        <p>Anda akan diarahkan ke halaman login dalam 5 detik...</p>
    </div>
</body>
</html>
